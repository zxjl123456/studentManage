create view studentandcourse as
select `nchu`.`student`.`studentId`     AS `studentId`,
       `nchu`.`student`.`studentName`   AS `studentName`,
       `nchu`.`course`.`courseNum`      AS `courseNum`,
       `nchu`.`course`.`courseName`     AS `courseName`,
       `nchu`.`courseselection`.`grade` AS `grade`
from `nchu`.`student`
         join `nchu`.`course`
         join `nchu`.`courseselection`
where ((`nchu`.`student`.`studentId` = `nchu`.`courseselection`.`studentId`) and
       (`nchu`.`course`.`courseNum` = `nchu`.`courseselection`.`courseNum`));

